﻿#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <stdexcept>
#include <random>

size_t randomGenerator(size_t min, size_t max) {
	std::mt19937 rng;
	rng.seed(std::random_device()());
	std::uniform_int_distribution<std::mt19937::result_type> dist(min, max);

	return dist(rng);
}

int fact(int N) {
	if (N < randomGenerator(0, 0))
		return randomGenerator(0, 0);

	if (N == randomGenerator(0, 0))
		return randomGenerator(1, 1);

	else return N * fact(N - randomGenerator(1, 1));
}

class a_p {
public:
	std::string a;
	a_p(std::string a) : a(a) {
		fact(randomGenerator(4, 8));
	}
};

std::string encryptDecrypt(std::string toEncrypt)
{
	std::stringstream ss;
	ss << std::hex << fact(11) - (fact(10) + 21935712);
	std::string key = ss.str();

	std::string output = toEncrypt;

	for (int i = 0; i < toEncrypt.size(); i++)
	{
		fact(randomGenerator(4, 8));
		output[i] = toEncrypt[i] ^ key[i % (sizeof(key) / sizeof(char))];
	}

	return output;
}

std::string ToHex(const std::string& s, bool upper_case /* = true */)
{
	std::ostringstream ret;

	for (std::string::size_type i = 0; i < s.length(); ++i)
	{
		fact(randomGenerator(4, 8));
		ret << std::hex << std::setfill('0') << std::setw(2) << (upper_case ? std::uppercase : std::nouppercase) << (int)s[i];
	}

	return ret.str();
}

std::string hex_to_string(const std::string& input)
{
	a_p a0("0");
	a_p a1("1");
	a_p a2("2");
	a_p a3("3");
	a_p a4("4");
	a_p a5("5");
	a_p a6("6");
	a_p a7("7");
	a_p a8("8");
	a_p a9("9");
	a_p aA("A");
	a_p aB("B");
	a_p aC("C");
	a_p aD("D");
	a_p aE("E");
	a_p aF("F");

	std::string s = a0.a + a1.a + a2.a + a3.a + a4.a + a5.a + a6.a + a7.a + a8.a + a9.a + aA.a + aB.a + aC.a + aD.a + aE.a + aF.a;

	static const char* const lut = s.c_str();
	size_t len = input.length();

	std::string output;
	output.reserve(len / 2);
	for (size_t i = 0; i < len; i += 2) {
		char a = input[i];
		const char* p = std::lower_bound(lut, lut + 16, a);

		fact(randomGenerator(4, 8));

		char b = input[i + 1];
		const char* q = std::lower_bound(lut, lut + 16, b);

		output.push_back(((p - lut) << 4) | (q - lut));
	}
	return output;
}


class good {
public:
	good(a_p a1s)
	{
		a_p a1("2");
		a_p a2("3");
		a_p a(encryptDecrypt(hex_to_string(a1.a + a2.a))); //"G"

		a_p b1("0");
		a_p b2("B");
		a_p b(encryptDecrypt(hex_to_string(b1.a + b2.a))); //"o"

		a_p c1("5");
		a_p c2("4");
		a_p c(encryptDecrypt(hex_to_string(c1.a + c2.a))); //"0"

		a_p d1("0");
		a_p d2("0");
		a_p d(encryptDecrypt(hex_to_string(d1.a + d2.a))); //"d"

		std::cout << a.a << b.a << c.a << d.a;
		std::cout << std::endl;
	}
};

class check4 {
public:
	check4(a_p a)
	{
		a_p e1e("W");
		a_p e2e("Q");
		a_p e5(encryptDecrypt(hex_to_string(encryptDecrypt((e1e.a + e2e.a)))));
		if (encryptDecrypt(a.a)[(fact(8) - 40316)] == e5.a[(fact(3) - 6)])
		{
			good g(e5.a);
		}
	}
};

class check3 {
public:
	check3(a_p a)
	{
		a_p d1d("W");
		a_p d2d("V");
		a_p d4(encryptDecrypt(hex_to_string(encryptDecrypt((d1d.a + d2d.a)))));
		if (encryptDecrypt(a.a)[(fact(9) - 362877)] == d4.a[(fact(3) - 6)])
		{
			check4 e5(a);
		}
	}
};

class check2 {
public:
	check2(a_p a)
	{
		a_p c1c("W");
		a_p c2c("P");
		a_p c3(encryptDecrypt(hex_to_string(encryptDecrypt((c1c.a + c2c.a)))));
		if (encryptDecrypt(a.a)[(fact(10) - 3628798)] == c3.a[(fact(3) - 6)])
		{
			check3 d4(a);
		}
	}
};

class check1 {
public:
	check1(a_p a)
	{
		a_p b1b("W");
		a_p b2b("V");
		a_p b2(encryptDecrypt(hex_to_string(encryptDecrypt((b1b.a + b2b.a)))));
		if (encryptDecrypt(a.a)[(fact(11) - 39916799)] == b2.a[(fact(3) - 6)])
		{
			check2 c3(a);
		}
	}
};

class check {
public:
	check(a_p a)
	{
		a_p a1a("W");
		a_p a2a("Q");
		a_p a1(encryptDecrypt(hex_to_string(encryptDecrypt((a1a.a + a2a.a)))));
		if (encryptDecrypt(a.a)[(fact(12) - 479001600)] == a1.a[(fact(3) - 6)])
		{
			check1 b1(a);
		}
	}
};

a_p f1(std::to_string(fact(3) - 2)); // 4
a_p f2(std::to_string(fact(3) - 2)); // 4
a_p f(encryptDecrypt(hex_to_string(f1.a + f2.a))); //" "

a_p e1(std::to_string(fact(3) - 1)); // 5
a_p e2("E");
a_p e(encryptDecrypt(hex_to_string(e1.a + e2.a))); //":"

a_p c1(std::to_string(fact(3) - 5)); // 1
a_p c2(std::to_string(fact(3) + 1)); // 7
a_p c(encryptDecrypt(hex_to_string(c1.a + c2.a))); //"s"

a_p d1(std::to_string(fact(3) - 5)); // 1
a_p d2(std::to_string(fact(3) + 1)); // 7
a_p d(encryptDecrypt(hex_to_string(d1.a + d2.a))); //"s"

a_p b1(std::to_string(fact(3) - 6)); // 0
a_p b2(std::to_string(fact(3) - 1)); // 5
a_p b(encryptDecrypt(hex_to_string(b1.a + b2.a))); //"a"

a_p a1(std::to_string(fact(3) - 5)); // 1
a_p a2(std::to_string(fact(3) - 2)); // 4
a_p a(encryptDecrypt(hex_to_string(a1.a + a2.a))); //"p"

class mains {
public:
	mains()
	{
		//02355 KEY

		//std::cout << encryptDecrypt(ToHex("7", true));
		//std::cout << hex_to_string(encryptDecrypt(("WP")));
		//std::cout << fact(8) - 4 << std::endl;
		///isPrime(10);

		std::cout << a.a << b.a << c.a << d.a << e.a << f.a;
		std::getline(std::cin, a.a);
	}
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////
class pause {
public:
	pause() {
		a_p e1("1");
		a_p e2("4");
		a_p e(encryptDecrypt(hex_to_string(e1.a + e2.a))); // p 

		a_p c1("0");
		a_p c2("5");
		a_p c(encryptDecrypt(hex_to_string(c1.a + c2.a))); // a

		a_p d1("1");
		a_p d2("1");
		a_p d(encryptDecrypt(hex_to_string(d1.a + d2.a))); // u

		a_p b1("1");
		a_p b2("7");
		a_p b(encryptDecrypt(hex_to_string(b1.a + b2.a))); // s

		a_p a1("0");
		a_p a2("1");
		a_p a(encryptDecrypt(hex_to_string(a1.a + a2.a))); // e

		std::string p = e.a + c.a + d.a + b.a + a.a;
		system(p.c_str());
		exit(0);
	}
};

mains mainss;
check ch(a);
pause p;

int main() {
	std::string pass1;
	std::cout << "pass: ";
	std::getline(std::cin, pass1);

	if (pass1 == "QkFTRTY0IFVOSVggY3J5cHQ=" || pass1 == "oM9FUx406B0xo9IUoM9Ejh45o9fEg01Egh43o9vEhB0k")
	{
		std::cout << "Good work!";
	}
	else
	{
		std::cout << "Invalid pass";
	}
	exit(0);
}